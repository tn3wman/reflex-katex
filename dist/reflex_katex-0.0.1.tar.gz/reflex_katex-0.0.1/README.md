# katex

A Reflex custom component katex.

## Installation

```bash
pip install reflex-katex
```